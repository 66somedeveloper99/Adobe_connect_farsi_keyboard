package com.someone.ck;
import android.inputmethodservice.*;
import android.view.View.*;
import android.view.*;
import android.view.inputmethod.*;
import android.text.*;
import android.graphics.drawable.*;

public class MyInputMethodService extends InputMethodService implements KeyboardView.OnKeyboardActionListener
{

    @Override
    public View onCreateInputView()
    {
	KeyboardView keyboardView =(KeyboardView) getLayoutInflater ().inflate (R.layout.keyboard_view, null);
	Keyboard keyboard = new Keyboard (this, R.xml.number_pad);
	keyboardView.setKeyboard (keyboard); 
	keyboardView.setOnKeyboardActionListener (this);
	keyboardView.setPreviewEnabled (false);
	keyboardView.setAlpha(0.9f);
	keyboardView.setBackgroundResource (R.drawable.keyboard_bckgrnd);

	return keyboardView;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes)
    {
	InputConnection ic = getCurrentInputConnection ();
	if (ic == null) return;
	switch (primaryCode)
	{
	    case Keyboard.KEYCODE_DELETE :
		CharSequence selectedText = ic.getSelectedText (0);
		if (TextUtils.isEmpty (selectedText))
		{
		    // nothing is not selected, so delete the previous character
		    ic.deleteSurroundingText (1, 0);
		}
		else
		{
		    // delete selected characters
		    ic.commitText ("", 1);
		}
		break;
	    case KeyEvent.KEYCODE_SPACE:
	        char code = (char) primaryCode;
                ic.commitText (String.valueOf (code), 1);
		break;
	    default:
		char _code = (char) primaryCode;
                ic.commitText (String.valueOf (_code), 1);
		
	}
    }

    @Override
    public void onPress(int p1)
    {
	// TODO: Implement this method
    }

    @Override
    public void onRelease(int p1)
    {
	// TODO: Implement this method
    }


    @Override
    public void onText(CharSequence p1)
    {
	// TODO: Implement this method
    }

    @Override
    public void swipeLeft()
    {
	// TODO: Implement this method
    }

    @Override
    public void swipeRight()
    {
	// TODO: Implement this method
    }

    @Override
    public void swipeDown()
    {
	// TODO: Implement this method
    }

    @Override
    public void swipeUp()
    {
	// TODO: Implement this method
    }

}
